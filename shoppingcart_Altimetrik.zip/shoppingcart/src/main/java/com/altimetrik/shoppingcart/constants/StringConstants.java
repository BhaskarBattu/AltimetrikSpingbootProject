package com.altimetrik.shoppingcart.constants;

public class StringConstants {

	public static final int SUCCESS = 200;
	public static final int REDIRECTION = 300;
	public static final int FORBIDDEN = 403;
	public static final int BADREQUEST = 400;
	public static final int UNAUTHORIZED = 401;
}
