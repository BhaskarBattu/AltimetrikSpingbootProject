package com.altimetrik.shoppingcart.models;

import java.util.List;

import org.springframework.stereotype.Component;

import com.altimetrik.shoppingcart.Items.Product;

@Component
public class CartItemsList {

	public List<Product> listofCartItems;

	public CartItemsList() {
		super();
	}

	public List<Product> getListofCartItems() {
		return listofCartItems;
	}

	public void setListofCartItems(List<Product> listofCartItems) {
		this.listofCartItems = listofCartItems;
	}

	public CartItemsList(List<Product> listofCartItems) {
		super();
		this.listofCartItems = listofCartItems;
	}
	
	
}
