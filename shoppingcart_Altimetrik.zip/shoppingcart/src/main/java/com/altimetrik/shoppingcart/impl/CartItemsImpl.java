package com.altimetrik.shoppingcart.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altimetrik.shoppingcart.Response;
import com.altimetrik.shoppingcart.Items.CartList;
import com.altimetrik.shoppingcart.Items.Product;
import com.altimetrik.shoppingcart.Items.ProductsList;
import com.altimetrik.shoppingcart.constants.StringConstants;
import com.altimetrik.shoppingcart.models.CartItemsList;

@Service
public class CartItemsImpl {

	@Autowired
	CartItemsList cartItemsList;
	
	public Response getAllCartItems()
	{
		CartList cartList = new CartList();
		
		if(cartList.displayAllProductsIncart().size() != 0)
		{
			cartItemsList.setListofCartItems(cartList.displayAllProductsIncart());
			
		}
		else
		{
			System.out.println("Your cart is empty");
		}
		Object o = cartItemsList;
		
		Response resp = new Response(o,StringConstants.SUCCESS);
		
		return resp;
	}
	
	public Response addProdutToList(int id)
	{
		
		CartList cartList = new CartList();
		
		int cartSize = cartList.displayAllProductsIncart().size();
				
		Response stsresp = checkStockAvailable(id);
		
		if(stsresp.getResp() != null)
			return stsresp;
		
		cartList.addProductToCard(id);
				
		decreaseOrIncreaseProductStockFromId(id,1);
		
		int cartsecSize = cartList.displayAllProductsIncart().size();
		
		if(cartsecSize > cartSize)
		{
			System.out.println("Added items to cart");
		}
		
		if(cartList.displayAllProductsIncart().size() != 0)
		{
			cartItemsList.setListofCartItems(cartList.displayAllProductsIncart());
			
		}
		else
		{
			System.out.println("Your cart is empty");
		}
		
		Object o = cartItemsList;
		
		Response resp = new Response(o,StringConstants.SUCCESS);
		
		return resp;
	}
	
	public Response removeProdutTocart(int id)
	{
		
		CartList cartList = new CartList();
		
		int cartSize = cartList.displayAllProductsIncart().size();
				
		if(cartSize > 0)
		{
			Response stsresp = checkStockAvailable(id);
			
			if(stsresp.getResp() != null)
				return stsresp;
			
			cartList.removeProductfromCart(id);
			
			decreaseOrIncreaseProductStockFromId(id,0);
		}
		
		if(cartList.displayAllProductsIncart().size() != 0)
		{
			cartItemsList.setListofCartItems(cartList.displayAllProductsIncart());
			
		}
		else
		{
			System.out.println("Your cart is empty");
		}
		
		Object o = cartItemsList;
		
		Response resp = new Response(o,StringConstants.SUCCESS);
		
		return resp;
	}
	
	public Response checkStockAvailable(int id)
	{
		Response resp = null;
		String ss = null;
		
		ProductsList plist = new ProductsList();
				
		Product oldP = null;
		List<Product> allPro = plist.getProductsList();
		
		for(Product p : allPro)
		{
			if(p.getId() == id)
			{
				
				oldP = p;
				break;
			}
		}
		
		if(oldP == null)
		{
			System.out.println("Product Is not there so we cant do ");	
		}
		else if(oldP != null && oldP.getStockList() <= 0)
		{
			System.out.println("Stock Is not there at this TIme");
		}
		
		Object o = ss;
		resp = new Response(o,StringConstants.SUCCESS); 
		
		return resp;
	}
	
	public void decreaseOrIncreaseProductStockFromId(int productId, int val)
	{
		System.out.println("Product stocke increased or decreased ");
		ProductsList plist = new ProductsList();
		List<Product> allPro = plist.getProductsList();
		
		Product oldP = null;
		
		for(int i=0; i < allPro.size() ; i++)
		{
			if(allPro.get(i).getId() == productId)
			{				
				oldP = allPro.get(i);
				break;
			}
		}
		if(oldP != null)
		{
			Product newP = oldP;	
			plist.removeProduct(newP);
			int updatedstock = 0;
			
			if(val == 1)
			{
				updatedstock = oldP.getStockList() - 1;
			}
			else
			{
				updatedstock = oldP.getStockList() + 1;
			}
			oldP.setStockList(updatedstock);	
			plist.addProduct(oldP);
		}
		
	}
}
