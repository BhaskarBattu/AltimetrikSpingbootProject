package com.altimetrik.shoppingcart.Items;

public class Product {

	public int id;
	public String productName;
	public Double productPrice;
	public int stockList;
	
	public Product()
	{
		
	}
	public Product(int id, String productName, Double productPrice, int stockList) {
		super();
		this.id = id;
		this.productName = productName;
		this.productPrice = productPrice;
		this.stockList = stockList;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}
	public int getStockList() {
		return stockList;
	}
	public void setStockList(int stockList) {
		this.stockList = stockList;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		result = prime * result + ((productPrice == null) ? 0 : productPrice.hashCode());
		result = prime * result + stockList;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (id != other.id)
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		if (productPrice == null) {
			if (other.productPrice != null)
				return false;
		} else if (!productPrice.equals(other.productPrice))
			return false;
		if (stockList != other.stockList)
			return false;
		return true;
	}
	
	
}
