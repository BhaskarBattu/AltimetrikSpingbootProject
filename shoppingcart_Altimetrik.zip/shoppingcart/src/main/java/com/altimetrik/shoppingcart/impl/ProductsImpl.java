package com.altimetrik.shoppingcart.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altimetrik.shoppingcart.Response;
import com.altimetrik.shoppingcart.Items.Product;
import com.altimetrik.shoppingcart.Items.ProductsList;
import com.altimetrik.shoppingcart.constants.StringConstants;
import com.altimetrik.shoppingcart.models.ProductItemsList;

@Service
public class ProductsImpl {

	@Autowired
	ProductItemsList productitemList;
	
	public Response getAllProducts()
	{
		ProductsList plist = new ProductsList();
		
		System.out.println("size og all lust:"+plist.getProductsList().size());
		productitemList.setListofProducts(plist.getProductsList());
		
		Object o = productitemList;
		
		Response resp = new Response(o,StringConstants.SUCCESS);
		
		return resp;
	}
	
	public Response addProdutToList(Product p)
	{
		System.out.println("Started adding to Product List");
		
		Response checkResp = checkNullCondition(p);
		
		if(checkResp.getResp() == null)
			return checkResp;
		
		ProductsList plist = new ProductsList();
		
		List<Product> allPro = plist.getProductsList();
		
		int check = checkProductIdAvilableOrNot(allPro,p,0);
		
		String ss = null;
		
		if(check == 1)
				ss = "Product Id or Product Name exits so we cant add";
		else
		{
				plist.addProduct(p);
				ss = "Product added Successfully";
		}
				
		Object o = ss;
		
		Response resp = new Response(o,StringConstants.SUCCESS);
		
		return resp;
	}
	
	public Response removeProdutFromList(int productId)
	{
		System.out.println("Started remove product from List");
				
		ProductsList plist = new ProductsList();
		
		List<Product> allPro = plist.getProductsList();
		
		Product checkP = checkProductIdAvilableOrNot(allPro,productId);
		
		String ss = null;
		
		if(checkP != null)
		{
				ss = "Product is removed";
				
				plist.removeProduct(checkP);
		}
		else
		{
				ss = "Product Id or Product Name exits so we cant remove";
		}
				
		Object o = ss;
		
		Response resp = new Response(o,StringConstants.SUCCESS);
		
		return resp;
	}
	
	public Product checkProductIdAvilableOrNot(List<Product> allPro,int productId)
	{		
		Product p = null;
		for(Product li : allPro)
		{
			if(li.getId() == productId)
			{				
				p = li;
				break;
			}
		}
		return p;
	}
	public int checkProductIdAvilableOrNot(List<Product> allPro,Product p, int checkIdandName)
	{
		System.out.println("Product Id:"+p.getId());
		int check = 0;
		
		for(Product li : allPro)
		{
			if(checkIdandName == 0 )
			{
				if(li.getId() == p.getId() || li.getProductName() == p.getProductName())
				{
					check = 1;
					break;
				}
			}else
			{
				if(li.getId() == p.getId())
				{
					check = 1;
					break;
				}
			}
		}
		System.out.println("Staus:"+check);
		return check;
	}
	
	public Response updateStockBasedOnID(Product p)
	{
		System.out.println("Started updatin stock");
		
		ProductsList plist = new ProductsList();
		
		List<Product> allPro = plist.getProductsList();
		
		String ss = null;
		
		int check = checkProductIdAvilableOrNot(allPro,p,1);
		
		if(check == 1)
		{			
			Product updatePro = checkProductIdAvilableOrNot(allPro,p.getId());
			
			if(updatePro.getStockList() < p.getStockList())
			{
				
				Product old = updatePro;
				
				updatePro.setStockList(p.getStockList());
				
				plist.removeProduct(old);
				plist.addProduct(updatePro);
				
				ss = "Stock updated Properly";	
			}
			else
			{
				ss = "Stock value is less than pls update properly";	
			}
			
		}
		else
		{
				ss = "Stock Not updated";
		}
				
		Object o = ss;
		
		Response resp = new Response(o,StringConstants.SUCCESS);
		
		return resp;
	}
	
	public Response checkNullCondition(Product p)
	{
		Response resp = null;
		String ss = null;
		
		if(p.getId() <= 0 )
		{
			ss = "Product Id is not there ";		
		}
		else if(p.getProductName() != null)
			{
				ss = "Product Name is not there ";
				
			}else if(p.getProductPrice() != null)
			{
				ss = "Product Price is not there ";
				
			}else if(p.getStockList() <= 0)
			{
				ss = "Product Stock is not there ";				
			}
			
		Object o = ss;
		resp = new Response(o,StringConstants.SUCCESS); 
		
		return resp;
	}
}
