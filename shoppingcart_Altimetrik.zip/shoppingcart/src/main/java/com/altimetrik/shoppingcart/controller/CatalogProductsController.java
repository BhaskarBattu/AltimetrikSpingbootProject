package com.altimetrik.shoppingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.altimetrik.shoppingcart.Response;
import com.altimetrik.shoppingcart.Items.Product;
import com.altimetrik.shoppingcart.impl.ProductsImpl;

@RestController
@RequestMapping("/catalog")
public class CatalogProductsController {

	@Autowired
	Response response;
	
	@Autowired
	ProductsImpl productImpl;
	
	@Autowired
	RestTemplate restTemp;
	
	@GetMapping("/")
	public ResponseEntity<Object> Hello()
	{
		System.out.println("catalog IT started");
		
		Object o = response.getResp();
		
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(o);
	}
	
	@GetMapping("/productsList")
	public ResponseEntity<Object> getAllProducts()
	{
		System.out.println("Dispalying all prodcuts");
		
		Object o = productImpl.getAllProducts();
		
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(o);
	}
	
	@PostMapping("/addProduct")
	public ResponseEntity<Object> addNewProduct(@RequestBody Product p)
	{
		System.out.println("Started added Product");
		
		Object o = productImpl.addProdutToList(p);
				
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(o);
	
	}
	
	@GetMapping("/removeProduct")
	public ResponseEntity<Object> removeProductFromList(@RequestParam int id)
	{
		System.out.println("Started remove Product");
		
		Object o = productImpl.removeProdutFromList(id);
				
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(o);
	
	}
	
	@PutMapping("/updateStock")
	public ResponseEntity<Object> updateStockBasedOnID(@RequestBody Product p)
	{
		System.out.println("Update stock started");
		
			Object o = productImpl.updateStockBasedOnID(p);
		
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(o);
	}
	
	
	
	@GetMapping("/restCheckTemp")
	public ResponseEntity<Object> checkRestTemp()
	{
		
		System.out.println("HAI catalog");
		ResponseEntity<Object> obj = restTemp.getForEntity("http://localhost:8080/ecommerce/cart/listOfItems", Object.class);		
						
		return  ResponseEntity.status(HttpStatus.ACCEPTED).body(obj.getBody());
		
	}
}
