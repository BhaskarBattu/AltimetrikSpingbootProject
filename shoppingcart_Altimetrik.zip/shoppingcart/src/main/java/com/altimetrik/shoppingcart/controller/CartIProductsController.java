package com.altimetrik.shoppingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.altimetrik.shoppingcart.Response;
import com.altimetrik.shoppingcart.impl.CartItemsImpl;

@RestController
@RequestMapping("/cart")
public class CartIProductsController {

	@Autowired
	Response response;
	
	@Autowired
	CartItemsImpl cartItemImpl;
	
	@GetMapping("/")
	public ResponseEntity<Object> Hello()
	{
		System.out.println("cart IT started");
		
		Object o = response.getResp();
		
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(o);
	}
	
	@GetMapping("/listOfItems")
	public ResponseEntity<Object> getListOfItemsInCart()
	{
		System.out.println("cart list started");
		
		Object o = cartItemImpl.getAllCartItems();
		
		return ResponseEntity.status(HttpStatus.OK).body(o);
		//return "Bhaskar";
	}
	
	@GetMapping("/addProductToCart")
	public ResponseEntity<Object> addProductTOCart(@RequestParam int id)
	{
		System.out.println("Started added Product");
		
		Object o = cartItemImpl.addProdutToList(id);
				
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(o);
	
	}
	@GetMapping("/removeProductFromCart")
	public ResponseEntity<Object> removeProductfromCart(@RequestParam int id)
	{
		System.out.println("Started added Product");
		
		Object o = cartItemImpl.removeProdutTocart(id);
				
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(o);
	
	}
}
