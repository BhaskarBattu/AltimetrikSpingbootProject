package com.altimetrik.shoppingcart;

import org.springframework.stereotype.Component;

@Component
public class Response {
	
	public Object resp;
	
	public int status;
	
	public Response()
	{
		
	}
	public Response(Object resp, int status) {
		super();
		this.resp = resp;
		this.status = status;
	}

	
	public Object getResp() {
		return resp;
	}

	public void setResp(Object resp) {
		this.resp = resp;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	
	

}
