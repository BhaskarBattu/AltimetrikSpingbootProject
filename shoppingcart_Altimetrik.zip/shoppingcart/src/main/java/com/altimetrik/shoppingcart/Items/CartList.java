package com.altimetrik.shoppingcart.Items;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Configuration;

@Configuration
public class CartList {

	public static final List<Product> cartList = new ArrayList<Product>();
	
	public void addProductToCard(int productId)
	{
		System.out.println("Started Priduct adding to Cart");
		Product p = getProductById(productId);
		
		if(p!= null)
		{
			cartList.add(p);
			System.out.println("Product Added to cart");
		}
		else
			System.out.println("Product Not added to add");
		
	}
	
	public void removeProductfromCart(int productId)
	{
		System.out.println("Started Priduct adding to Cart");
		Product p = getCartProductById(productId);
		
		if(p!= null)
		{
			cartList.remove(p);
			System.out.println("Product Removed to cart");
		}
		else
			System.out.println("Product Not removed to cart");
		
	}
	
	public Product getCartProductById(int productId)
	{
		Product p = null;
		
		for(int i=0;i<cartList.size();i++)
		{
			if(cartList.get(i).getId() == productId)
			{
				p = cartList.get(i);
				
				break;
			}
		}
		return p;
	}
	
	public Product getProductById(int productId)
	{
		ProductsList plist = new ProductsList();
		List<Product> allProductsList = plist.getProductsList();
		
		Product p = null;
		
		for(int i=0;i<allProductsList.size();i++)
		{
			if(allProductsList.get(i).getId() == productId)
			{
				p = allProductsList.get(i);
				
				break;
			}
		}
		
		return p;
	}
	
	public List<Product> displayAllProductsIncart()
	{
		return cartList;
	}
	
	
}
