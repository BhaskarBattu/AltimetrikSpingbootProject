package com.altimetrik.shoppingcart.Items;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ProductsList {
	public static final List<Product> productList = new ArrayList<Product>();
	
	@Bean
	public void setShoppingProductsList()
	{
		ListOfShoppingProductsList();
	}
	public List<Product> getProductsList()
	{
		return productList;
	}
		
	
	public void ListOfShoppingProductsList()
	{
		String itemsList[]= {"Phone","dress","TV","books"};
		double itemsPrice[] = {20000,500,40000,200};
		int stockList[] = {3,2,6,4};
		
		System.out.println("Id   ShoppingItems  Price  StockAvailable");
		
		for(int i=0;i<itemsList.length;i++)
		{
			productList.add(new Product(i+1,itemsList[i],itemsPrice[i],stockList[i]));
		}
		Collections.sort(productList,(I1,I2)->{return I1.productPrice < I2.productPrice ? -1  :  I1.productPrice > I2.productPrice ? 1 : 0 ;});
		
		System.out.println("Successfully Loaded");
	}
	
	public void addProduct(Product p)
	{
		System.out.println("Inner maain");
		if(p!=null)
		{
			productList.add(p);
			
			Collections.sort(productList,(I1,I2)->{return I1.productPrice < I2.productPrice ? -1  :  I1.productPrice > I2.productPrice ? 1 : 0 ;});
		}
		System.out.println("Succesfully added to toal list");
	}
	
	public void removeProduct(Product p)
	{
		System.out.println("Inner maain");
		if(p!=null)
		{
			productList.remove(p);
			
			Collections.sort(productList,(I1,I2)->{return I1.productPrice < I2.productPrice ? -1  :  I1.productPrice > I2.productPrice ? 1 : 0 ;});
		}
		System.out.println("Succesfully removed to toal list");
	}
	
	public void updateProduct(Product p)
	{
		
		if(p!=null)
		{
			
			for(Product list: productList)
			{
				if(list.getId() == p.getId())
				{
					list.setStockList(p.stockList);
						break;
				}
			}
		}
		
	}
}
