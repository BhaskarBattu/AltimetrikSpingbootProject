package com.altimetrik.shoppingcart.models;

import java.util.List;

import org.springframework.stereotype.Component;

import com.altimetrik.shoppingcart.Items.Product;

@Component
public class ProductItemsList {

	
	public List<Product> listofProducts;

	
	public ProductItemsList() {
		super();
	}

	@Override
	public String toString() {
		return "ProductItemsList [listofProducts=" + listofProducts + "]";
	}

	public ProductItemsList(List<Product> listofProducts) {
		super();
		
		this.listofProducts = listofProducts;
	}

	

	public List<Product> getListofProducts() {
		return listofProducts;
	}

	public void setListofProducts(List<Product> listofProducts) {
		this.listofProducts = listofProducts;
	}
	
}
