package com.altimetrik.shoppingcart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingcartApplicationTests {

	@Test
	void contextLoads() {
	}

}
